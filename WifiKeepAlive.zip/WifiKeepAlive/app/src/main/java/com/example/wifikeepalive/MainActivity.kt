package com.example.wifikeepalive

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var router: TextView
    private lateinit var internet: TextView
    private lateinit var last: TextView
    private lateinit var hint: TextView
    private lateinit var toggle: Button

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, r: Int = 16) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat()
    }

    private fun text(size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        textSize = size; setTextColor(color)
        if (bold) setTypeface(null, Typeface.BOLD)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF0F172A.toInt())
            setPadding(dp(20), dp(56), dp(20), dp(24))
        }
        root.addView(text(28f, Color.WHITE, true).apply { this.text = "Wifi Activa" })
        root.addView(text(14f, 0xFF94A3B8.toInt()).apply {
            this.text = "Mantiene tu wifi siempre conectada"
            setPadding(0, dp(4), 0, dp(24))
        })

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(0xFF1E293B.toInt(), 20)
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }
        status = text(22f, Color.WHITE, true).apply { setPadding(0, 0, 0, dp(12)) }
        router = text(16f, Color.WHITE).apply { setPadding(0, dp(4), 0, dp(4)) }
        internet = text(16f, Color.WHITE).apply { setPadding(0, dp(4), 0, dp(4)) }
        last = text(13f, 0xFF94A3B8.toInt()).apply { setPadding(0, dp(8), 0, 0) }
        listOf(status, router, internet, last).forEach { card.addView(it) }
        root.addView(card)

        hint = text(13f, 0xFFFBBF24.toInt()).apply { setPadding(0, dp(12), 0, 0) }
        root.addView(hint)

        toggle = Button(this).apply {
            textSize = 18f; isAllCaps = false; setTextColor(Color.WHITE)
            setOnClickListener { onToggle() }
        }
        root.addView(toggle, LinearLayout.LayoutParams(-1, dp(60)).apply { topMargin = dp(24) })

        val battery = Button(this).apply {
            text = "Quitar optimización de batería"
            isAllCaps = false; setTextColor(Color.WHITE)
            background = rounded(0xFF334155.toInt())
            setOnClickListener { askBattery() }
        }
        root.addView(battery, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(12) })

        root.addView(text(12f, 0xFF64748B.toInt()).apply {
            gravity = Gravity.CENTER
            this.text = "Envía una comprobación al router cada 20 s para que no apague la wifi por inactividad."
            setPadding(0, dp(20), 0, 0)
        })
        setContentView(root)
    }

    private fun onToggle() {
        val i = Intent(this, WifiKeepAliveService::class.java)
        if (WifiKeepAliveService.running) {
            stopService(i)
            Toast.makeText(this, "Detenido", Toast.LENGTH_SHORT).show()
        } else {
            try {
                startForegroundService(i)
                Toast.makeText(this, "Wifi activa iniciada", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
        handler.postDelayed({ refresh() }, 300)
    }

    private fun askBattery() {
        val pm = getSystemService(PowerManager::class.java)
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            Toast.makeText(this, "Ya está excluida de la optimización", Toast.LENGTH_SHORT).show()
        } else {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:$packageName"))
            )
        }
    }

    private fun mark(ok: Boolean?, label: String, extra: String = ""): String = when (ok) {
        true -> "🟢  $label: conectado$extra"
        false -> "🔴  $label: sin respuesta"
        null -> "⚪  $label: esperando..."
    }

    private fun refresh() {
        val on = WifiKeepAliveService.running
        status.text = if (on) "● ACTIVO" else "● DETENIDO"
        status.setTextColor(if (on) 0xFF4ADE80.toInt() else 0xFFF87171.toInt())
        router.text = mark(if (on) WifiKeepAliveService.routerOk else null, "Router (${WifiKeepAliveService.gateway})")
        val lat = WifiKeepAliveService.latencyMs
        internet.text = mark(
            if (on) WifiKeepAliveService.netOk else null, "Internet",
            if (lat >= 0) " ($lat ms)" else ""
        )
        val t = WifiKeepAliveService.lastCheck
        last.text = if (on && t > 0)
            "Última comprobación: " + SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(t))
        else "Sin comprobaciones todavía"
        toggle.text = if (on) "Detener" else "Iniciar wifi activa"
        toggle.background = rounded(if (on) 0xFFDC2626.toInt() else 0xFF16A34A.toInt(), 30)

        val noNotif = Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        hint.text = if (noNotif) "⚠ Activa los permisos de notificaciones de la app para ver el estado fuera de ella." else ""
    }

    private val ticker = object : Runnable {
        override fun run() { refresh(); handler.postDelayed(this, 1000) }
    }

    override fun onResume() { super.onResume(); ticker.run() }
    override fun onPause() { super.onPause(); handler.removeCallbacks(ticker) }
}
