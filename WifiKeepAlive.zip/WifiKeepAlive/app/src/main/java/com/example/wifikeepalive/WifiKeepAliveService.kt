package com.example.wifikeepalive

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import kotlinx.coroutines.*
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URL

class WifiKeepAliveService : Service() {

    companion object {
        @Volatile var running = false
        @Volatile var routerOk: Boolean? = null
        @Volatile var netOk: Boolean? = null
        @Volatile var latencyMs: Long = -1
        @Volatile var lastCheck: Long = 0
        @Volatile var gateway: String = "-"
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var wifiLock: WifiManager.WifiLock? = null
    private val intervalMs = 20_000L

    override fun onCreate() {
        super.onCreate()
        running = true
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("wifi", "Wifi activa", NotificationManager.IMPORTANCE_LOW)
        )
        val n = notif("Iniciando...")
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }

        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "keepalive").apply {
            setReferenceCounted(false)
            acquire()
        }

        scope.launch {
            while (isActive) {
                val gw = gatewayIp(wm)
                gateway = gw ?: "-"
                routerOk = gw?.let { ping(it) } ?: false
                val t0 = System.currentTimeMillis()
                netOk = head("http://connectivitycheck.gstatic.com/generate_204")
                latencyMs = if (netOk == true) System.currentTimeMillis() - t0 else -1
                lastCheck = System.currentTimeMillis()
                updateNotif(
                    "Router: ${if (routerOk == true) "OK" else "NO"} | " +
                        "Internet: ${if (netOk == true) "OK" else "NO"}"
                )
                delay(intervalMs)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    private fun gatewayIp(wm: WifiManager): String? {
        val g = wm.dhcpInfo?.gateway ?: return null
        if (g == 0) return null
        return "%d.%d.%d.%d".format(g and 0xff, g shr 8 and 0xff, g shr 16 and 0xff, g shr 24 and 0xff)
    }

    private fun ping(host: String): Boolean = try {
        InetAddress.getByName(host).isReachable(3000)
    } catch (e: Exception) { false }

    private fun head(url: String): Boolean = try {
        (URL(url).openConnection() as HttpURLConnection).run {
            requestMethod = "HEAD"; connectTimeout = 4000; readTimeout = 4000
            val ok = responseCode in 200..399
            disconnect(); ok
        }
    } catch (e: Exception) { false }

    private fun notif(text: String): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, "wifi")
            .setContentTitle("Wifi activa")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun updateNotif(text: String) =
        getSystemService(NotificationManager::class.java).notify(1, notif(text))

    override fun onDestroy() {
        running = false
        scope.cancel()
        wifiLock?.release()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
