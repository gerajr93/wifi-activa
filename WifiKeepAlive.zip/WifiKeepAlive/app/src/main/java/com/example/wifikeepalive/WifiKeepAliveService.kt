package com.example.wifikeepalive

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.wifi.WifiManager
import android.os.IBinder
import kotlinx.coroutines.*
import java.net.InetAddress
import java.net.HttpURLConnection
import java.net.URL

class WifiKeepAliveService : Service() {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var wifiLock: WifiManager.WifiLock? = null
    private val intervalMs = 20_000L

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("wifi", "Wifi activa", NotificationManager.IMPORTANCE_LOW)
        )
        startForeground(1, notif("Iniciando..."))

        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "keepalive").apply {
            setReferenceCounted(false)
            acquire()
        }

        scope.launch {
            while (isActive) {
                val gateway = gatewayIp(wm)
                val router = gateway?.let { ping(it) } ?: false
                val net = head("http://connectivitycheck.gstatic.com/generate_204")
                updateNotif("Router: ${if (router) "OK" else "NO"} | Internet: ${if (net) "OK" else "NO"}")
                delay(intervalMs)
            }
        }
    }

    private fun gatewayIp(wm: WifiManager): String? {
        val g = wm.dhcpInfo?.gateway ?: return null
        if (g == 0) return null
        return "%d.%d.%d.%d".format(g and 0xff, g shr 8 and 0xff, g shr 16 and 0xff, g shr 24 and 0xff)
    }

    private fun ping(host: String): Boolean = try {
        InetAddress.getByName(host).isReachable(3000)
    } catch (e: Exception) { false }

    private fun head(url: String): Boolean = try {
        (URL(url).openConnection() as HttpURLConnection).run {
            requestMethod = "HEAD"; connectTimeout = 4000; readTimeout = 4000
            val ok = responseCode in 200..399
            disconnect(); ok
        }
    } catch (e: Exception) { false }

    private fun notif(text: String): Notification =
        Notification.Builder(this, "wifi")
            .setContentTitle("Wifi activa")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setOngoing(true)
            .build()

    private fun updateNotif(text: String) =
        getSystemService(NotificationManager::class.java).notify(1, notif(text))

    override fun onDestroy() {
        scope.cancel()
        wifiLock?.release()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
